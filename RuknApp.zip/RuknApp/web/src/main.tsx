import { createRoot } from "react-dom/client";
import "./styles.css";
import { ReceiverApp } from "@/components/receiver/receiver-app";

createRoot(document.getElementById("root")!).render(<ReceiverApp />);
