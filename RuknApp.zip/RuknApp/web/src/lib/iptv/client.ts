export function uid(prefix: string) {
  const bytes = crypto.randomUUID().replace(/-/g, "").slice(0, 10);
  return `${prefix}_${bytes}`;
}

// التطبيق يجلب الروابط مباشرة؛ الطبقة الأصلية في أندرويد تتولى تجاوز قيود CORS.
export async function fetchPlaylistText(url: string): Promise<string> {
  const response = await fetch(url);
  const text = await response.text();
  if (!response.ok) throw new Error("تعذّر تحميل القائمة.");
  return text;
}

export function mediaUrl(url: string) {
  return url;
}

export function logoUrl(logo?: string) {
  if (!logo) return "";
  return logo.startsWith("http://") || logo.startsWith("https://") ? logo : "";
}
