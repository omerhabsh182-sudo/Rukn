import type { Channel } from "@/lib/iptv/types";
import { channelId } from "@/lib/iptv/parse-m3u";

const samples: Array<Pick<Channel, "name" | "url">> = [
  {
    name: "أرنب كبير — عيّنة",
    url: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
  },
  {
    name: "دموع الفولاذ — عيّنة",
    url: "https://test-streams.mux.dev/tos_ismc/main.m3u8",
  },
  {
    name: "سينتل — عيّنة",
    url: "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8",
  },
];

export const DEMO_SOURCE_ID = "demo";

export const DEMO_CHANNELS: Channel[] = samples.map((sample, index) => ({
  id: channelId(sample.url),
  num: index + 1,
  name: sample.name,
  url: sample.url,
  group: "عيّنات مجانية",
}));
