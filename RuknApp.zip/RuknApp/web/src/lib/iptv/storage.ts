import type { Channel, Prefs } from "@/lib/iptv/types";

const LS_KEY = "rukn.prefs.v1";

export function emptyPrefs(): Prefs {
  return {
    sources: [],
    activeSourceId: null,
    favorites: [],
    lastChannelId: null,
    volume: 1,
    muted: false,
  };
}

export function loadPrefs(): Prefs {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return emptyPrefs();
    const parsed = JSON.parse(raw) as Partial<Prefs>;
    return {
      ...emptyPrefs(),
      ...parsed,
      sources: Array.isArray(parsed.sources) ? parsed.sources : [],
      favorites: Array.isArray(parsed.favorites) ? parsed.favorites : [],
      volume: typeof parsed.volume === "number" ? parsed.volume : 1,
    };
  } catch {
    return emptyPrefs();
  }
}

export function savePrefs(prefs: Prefs) {
  localStorage.setItem(LS_KEY, JSON.stringify(prefs));
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("rukn", 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains("libraries")) db.createObjectStore("libraries");
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function loadLibrary(sourceId: string): Promise<Channel[] | null> {
  try {
    const db = await openDb();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction("libraries", "readonly");
      const request = tx.objectStore("libraries").get(sourceId);
      request.onsuccess = () => {
        const value = request.result as { channels?: Channel[] } | undefined;
        resolve(value?.channels ?? null);
      };
      request.onerror = () => reject(request.error);
    });
  } catch {
    return null;
  }
}

export async function saveLibrary(sourceId: string, channels: Channel[]) {
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction("libraries", "readwrite");
      tx.objectStore("libraries").put({ channels, fetchedAt: Date.now() }, sourceId);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    /* keep the list in memory if storage is blocked */
  }
}

export async function deleteLibrary(sourceId: string) {
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction("libraries", "readwrite");
      tx.objectStore("libraries").delete(sourceId);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    /* ignore */
  }
}
