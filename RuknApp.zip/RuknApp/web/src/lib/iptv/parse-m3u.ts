import type { Channel } from "@/lib/iptv/types";

const MAX_CHANNELS = 20000;

function splitInf(line: string): { meta: string; name: string } {
  let quoted = false;
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') quoted = !quoted;
    else if (char === "," && !quoted) {
      return { meta: line.slice(0, i), name: line.slice(i + 1).trim() };
    }
  }
  return { meta: line, name: "" };
}

function readAttrs(meta: string): Record<string, string> {
  const out: Record<string, string> = {};
  const re = /([A-Za-z0-9-]+)="([^"]*)"/g;
  let match: RegExpExecArray | null;
  while ((match = re.exec(meta))) out[match[1].toLowerCase()] = match[2];
  return out;
}

function resolveUrl(raw: string, base?: string): string {
  try {
    return new URL(raw, base).toString();
  } catch {
    return "";
  }
}

export function channelId(url: string): string {
  let hash = 2166136261;
  for (let i = 0; i < url.length; i++) {
    hash ^= url.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return `c${(hash >>> 0).toString(36)}`;
}

export function parseM3u(raw: string, baseUrl?: string): Channel[] {
  const text = raw.replace(/^\uFEFF/, "");
  const lines = text.split(/\r?\n/);
  const channels: Channel[] = [];
  const seen = new Set<string>();
  let pending: { name: string; logo?: string; group?: string; tvgId?: string } | null = null;
  let extGroup: string | undefined;

  for (const lineRaw of lines) {
    const line = lineRaw.trim();
    if (!line) continue;
    const upper = line.toUpperCase();
    if (upper.startsWith("#EXTGRP:")) {
      extGroup = line.slice(line.indexOf(":") + 1).trim() || undefined;
      continue;
    }
    if (upper.startsWith("#EXTINF")) {
      const { meta, name } = splitInf(line);
      const attrs = readAttrs(meta);
      pending = {
        name: (name || attrs["tvg-name"] || "").trim(),
        logo: attrs["tvg-logo"]?.trim() || undefined,
        group: attrs["group-title"]?.trim() || extGroup,
        tvgId: attrs["tvg-id"]?.trim() || undefined,
      };
      continue;
    }
    if (line.startsWith("#")) continue;

    const url = resolveUrl(line, baseUrl);
    if (!url || seen.has(url)) {
      pending = null;
      continue;
    }
    seen.add(url);
    const num = channels.length + 1;
    channels.push({
      id: channelId(url),
      num,
      name: pending?.name || `قناة ${num}`,
      url,
      group: pending?.group?.trim() || "بدون تصنيف",
      logo: pending?.logo,
      tvgId: pending?.tvgId,
    });
    pending = null;
    if (channels.length >= MAX_CHANNELS) break;
  }

  return channels;
}

export function buildXtreamUrl(input: {
  url?: string;
  username?: string;
  password?: string;
  output?: "m3u8" | "ts";
}): string {
  const host = (input.url || "").trim();
  if (!host) throw new Error("اكتب عنوان السيرفر.");
  if (/get\.php/i.test(host) && /username=/i.test(host)) return host;
  const withProto = /^https?:\/\//i.test(host) ? host : `http://${host}`;
  let parsed: URL;
  try {
    parsed = new URL(withProto);
  } catch {
    throw new Error("عنوان السيرفر غير صالح.");
  }
  parsed.pathname = "/get.php";
  parsed.search = "";
  parsed.hash = "";
  parsed.username = "";
  parsed.password = "";
  parsed.searchParams.set("username", input.username?.trim() || "");
  parsed.searchParams.set("password", input.password || "");
  parsed.searchParams.set("type", "m3u_plus");
  parsed.searchParams.set("output", input.output === "ts" ? "ts" : "m3u8");
  return parsed.toString();
}
