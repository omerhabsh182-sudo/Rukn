export type SourceKind = "url" | "xtream" | "file";

export type Source = {
  id: string;
  name: string;
  kind: SourceKind;
  url?: string;
  username?: string;
  password?: string;
  output?: "m3u8" | "ts";
  createdAt: number;
};

export type Channel = {
  id: string;
  num: number;
  name: string;
  url: string;
  group: string;
  logo?: string;
  tvgId?: string;
};

export type Prefs = {
  sources: Source[];
  activeSourceId: string | null;
  favorites: string[];
  lastChannelId: string | null;
  volume: number;
  muted: boolean;
};
