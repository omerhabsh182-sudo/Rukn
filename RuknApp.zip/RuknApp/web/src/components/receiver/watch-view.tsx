import { useEffect, useRef, useState } from "react";
import { ChevronDown, ChevronUp, List, Pause, Play, Star, Volume2, VolumeX } from "lucide-react";
import { mediaUrl } from "@/lib/iptv/client";
import type { Channel } from "@/lib/iptv/types";

function looksLikeTs(url: string) {
  const path = url.split("?")[0]?.toLowerCase() ?? "";
  return path.endsWith(".ts") || /output=(ts|mpegts)\b/i.test(url);
}

export function WatchView({
  channel,
  favorite,
  volume,
  muted,
  osd,
  digits,
  onShowOsd,
  onClose,
  onPrev,
  onNext,
  onToggleFav,
  onVolume,
  onMuted,
}: {
  channel: Channel;
  favorite: boolean;
  volume: number;
  muted: boolean;
  osd: boolean;
  digits: string;
  onShowOsd: () => void;
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
  onToggleFav: () => void;
  onVolume: (value: number) => void;
  onMuted: (value: boolean) => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [retry, setRetry] = useState(0);
  const [phase, setPhase] = useState<"loading" | "playing" | "error">("loading");
  const [message, setMessage] = useState("جارٍ الاتصال بالبث");
  const [live, setLive] = useState(false);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    let gone = false;
    const cleanups: Array<() => void> = [];
    setPhase("loading");
    setMessage("جارٍ الاتصال بالبث");
    setPaused(false);

    const fail = (text: string) => {
      if (!gone) {
        setPhase("error");
        setMessage(text);
      }
    };

    const markLive = () => {
      if (gone) return;
      setLive(video.duration === Infinity);
    };
    const onPlaying = () => {
      if (!gone) setPhase("playing");
      markLive();
    };
    video.addEventListener("playing", onPlaying);
    video.addEventListener("durationchange", markLive);
    const onPause = () => {
      if (!gone) setPaused(true);
    };
    const onPlay = () => {
      if (!gone) setPaused(false);
    };
    video.addEventListener("pause", onPause);
    video.addEventListener("play", onPlay);
    cleanups.push(() => {
      video.removeEventListener("playing", onPlaying);
      video.removeEventListener("durationchange", markLive);
      video.removeEventListener("pause", onPause);
      video.removeEventListener("play", onPlay);
    });

    const proxied = mediaUrl(channel.url);

    const playNative = () => {
      video.src = proxied;
      void video.play().catch(() => fail("المتصفح منع التشغيل التلقائي. اضغط تشغيل."));
    };

    const playHls = async () => {
      const { default: Hls } = await import("hls.js");
      if (!Hls.isSupported()) {
        if (video.canPlayType("application/vnd.apple.mpegurl")) {
          playNative();
          return true;
        }
        return false;
      }
      const hls = new Hls({
        enableWorker: false,
        lowLatencyMode: true,
        manifestLoadingMaxRetry: 1,
        levelLoadingMaxRetry: 1,
      });
      cleanups.push(() => {
        try {
          hls.destroy();
        } catch {
          /* already destroyed on fallback */
        }
      });
      return await new Promise<boolean>((resolve) => {
        let settled = false;
        hls.on(Hls.Events.ERROR, (_event, data) => {
          if (!data.fatal || settled) return;
          settled = true;
          try {
            hls.destroy();
          } catch {
            /* already gone */
          }
          resolve(false);
        });
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          if (settled) return;
          settled = true;
          void video.play().catch(() => fail("اضغط تشغيل لبدء الصورة."));
          resolve(true);
        });
        window.setTimeout(() => {
          if (settled) return;
          settled = true;
          try {
            hls.destroy();
          } catch {
            /* already gone */
          }
          resolve(false);
        }, 12_000);
        hls.loadSource(proxied);
        hls.attachMedia(video);
      });
    };

    const playTs = async () => {
      const mpegts = (await import("mpegts.js")).default;
      if (!mpegts.isSupported()) return false;
      mpegts.LoggingControl.applyConfig({
        enableAll: false,
        enableDebug: false,
        enableVerbose: false,
        enableInfo: false,
        enableWarn: false,
        enableError: false,
      });
      const player = mpegts.createPlayer(
        { type: "mse", isLive: true, url: proxied },
        { enableWorker: false, enableStashBuffer: false, stashInitialSize: 128 },
      );
      cleanups.push(() => {
        try {
          player.pause();
          player.unload();
          player.detachMediaElement();
          player.destroy();
        } catch {
          /* already torn down */
        }
      });
      player.attachMediaElement(video);
      player.on(mpegts.Events.ERROR, () => fail("تعذّر قراءة بث TS. جرّب صيغة HLS من المصدر."));
      player.load();
      void video.play().catch(() => fail("اضغط تشغيل لبدء الصورة."));
      return true;
    };

    void (async () => {
      try {
        if (looksLikeTs(channel.url)) {
          const ok = await playTs();
          if (ok || gone) return;
        }
        const ok = await playHls();
        if (ok || gone) return;
        const tsOk = await playTs();
        if (!tsOk && !gone) playNative();
      } catch {
        if (!gone) fail("تعذّر تشغيل هذه القناة.");
      }
    })();

    return () => {
      gone = true;
      cleanups.forEach((fn) => fn());
      video.pause();
      video.removeAttribute("src");
      video.load();
    };
  }, [channel.url, retry]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    video.volume = volume;
    video.muted = muted;
  }, [volume, muted, phase]);

  const togglePause = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) void video.play().catch(() => undefined);
    else video.pause();
  };

  return (
    <div className="fixed inset-0 z-30 bg-ink" onMouseMove={onShowOsd}>
      <video
        ref={videoRef}
        className="h-full w-full bg-ink object-contain"
        playsInline
        autoPlay
        onClick={() => {
          onShowOsd();
          if (phase === "error") return;
          togglePause();
        }}
      />

      {digits && (
        <div className="pointer-events-none absolute inset-0 grid place-items-center">
          <div className="glass rounded-3xl px-10 py-6 text-6xl font-semibold tabular-nums text-amber" dir="ltr">
            {digits}
          </div>
        </div>
      )}

      {phase !== "playing" && (
        <div className="absolute inset-0 grid place-items-center p-6">
          <div className="glass rise max-w-md rounded-3xl px-6 py-5 text-center">
            <p className="text-lg font-medium">{message}</p>
            {phase === "error" && (
              <button className="btn btn-amber mt-4" type="button" onClick={() => setRetry((value) => value + 1)}>
                إعادة المحاولة
              </button>
            )}
          </div>
        </div>
      )}

      <div
        className={osd ? "opacity-100" : "pointer-events-none opacity-0"}
        style={{ transition: "opacity 180ms ease" }}
      >
        <div className="safe-t absolute inset-x-0 top-0 flex justify-center p-4">
          <div className="glass flex max-w-3xl items-center gap-4 rounded-full px-4 py-2">
            <span className="text-2xl font-semibold tabular-nums text-amber" dir="ltr">
              {String(channel.num).padStart(3, "0")}
            </span>
            <span className="min-w-0">
              <span className="block truncate font-semibold">{channel.name}</span>
              <span className="block truncate text-sm text-muted">{channel.group}</span>
            </span>
            <span className="ms-2 flex items-center gap-2 text-sm text-muted">
              <span className="live-dot" />
              {live ? "مباشر" : "مسجّل"}
            </span>
          </div>
        </div>

        <div className="safe-b absolute inset-x-0 bottom-0 flex justify-center p-4">
          <div className="glass flex w-full max-w-3xl flex-wrap items-center justify-center gap-2 rounded-3xl px-3 py-3">
            <button className="icon-btn" type="button" aria-label="القناة السابقة" onClick={onPrev}>
              <ChevronUp className="size-5" />
            </button>
            <button className="icon-btn" type="button" aria-label={paused ? "تشغيل" : "إيقاف مؤقت"} onClick={togglePause}>
              {paused ? <Play className="size-5" /> : <Pause className="size-5" />}
            </button>
            <button className="icon-btn" type="button" aria-label="القناة التالية" onClick={onNext}>
              <ChevronDown className="size-5" />
            </button>
            <button
              className="icon-btn"
              type="button"
              data-on={favorite ? "true" : "false"}
              aria-label="المفضلة"
              onClick={onToggleFav}
            >
              <Star className="size-4" fill={favorite ? "currentColor" : "none"} />
            </button>
            <button className="icon-btn" type="button" aria-label={muted ? "إلغاء الكتم" : "كتم"} onClick={() => onMuted(!muted)}>
              {muted || volume === 0 ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
            </button>
            <input
              className="h-11 w-28 accent-amber"
              aria-label="الصوت"
              type="range"
              min={0}
              max={1}
              step={0.05}
              dir="ltr"
              value={muted ? 0 : volume}
              onChange={(event) => {
                onMuted(false);
                onVolume(Number(event.target.value));
              }}
            />
            <button className="btn btn-glass" type="button" onClick={onClose}>
              <List className="size-4" />
              القائمة
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
