import { useEffect, useRef, useState } from "react";
import { RefreshCw, Search, Star, Tv } from "lucide-react";
import { cn } from "@/lib/cn";
import { logoUrl } from "@/lib/iptv/client";
import type { Channel } from "@/lib/iptv/types";

const ROW = 76;

function Clock() {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    const tick = () => setNow(new Date());
    tick();
    const id = window.setInterval(tick, 30_000);
    return () => window.clearInterval(id);
  }, []);
  if (!now) return <span className="tabular-nums text-muted">--:--</span>;
  return (
    <div className="text-end leading-tight">
      <div className="text-lg font-semibold tabular-nums" dir="ltr">
        {now.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}
      </div>
      <div className="hidden text-xs text-muted sm:block">
        {now.toLocaleDateString("ar", { weekday: "short", day: "numeric", month: "short" })}
      </div>
    </div>
  );
}

function ChannelLogo({ name, logo }: { name: string; logo?: string }) {
  const src = logoUrl(logo);
  const [broken, setBroken] = useState(false);
  useEffect(() => setBroken(false), [src]);
  return (
    <span className="grid size-11 shrink-0 place-items-center overflow-hidden rounded-full glass-soft">
      {src && !broken ? (
        <img
          src={src}
          alt=""
          className="size-full object-cover"
          loading="lazy"
          referrerPolicy="no-referrer"
          onError={() => setBroken(true)}
        />
      ) : (
        <span className="text-sm font-semibold text-amber">{name.trim().charAt(0) || "ر"}</span>
      )}
    </span>
  );
}

export function GuideView({
  sourceName,
  countLabel,
  loading,
  error,
  warning,
  demo,
  hasChannels,
  groups,
  groupId,
  onGroup,
  query,
  onQuery,
  channels,
  selectedId,
  onSelect,
  onPlay,
  favorites,
  onToggleFav,
  onOpenSources,
  onRefresh,
}: {
  sourceName: string;
  countLabel: string;
  loading: boolean;
  error: string | null;
  warning: string | null;
  demo: boolean;
  hasChannels: boolean;
  groups: { id: string; label: string; count: number }[];
  groupId: string;
  onGroup: (id: string) => void;
  query: string;
  onQuery: (value: string) => void;
  channels: Channel[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onPlay: (channel: Channel) => void;
  favorites: Set<string>;
  onToggleFav: (id: string) => void;
  onOpenSources: () => void;
  onRefresh: () => void;
}) {
  const scrollerRef = useRef<HTMLDivElement>(null);
  const [scrollTop, setScrollTop] = useState(0);
  const [viewport, setViewport] = useState(480);
  const selected = channels.find((channel) => channel.id === selectedId) ?? null;
  const selectedIndex = channels.findIndex((channel) => channel.id === selectedId);

  useEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;
    const measure = () => setViewport(el.clientHeight || 480);
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(el);
    return () => observer.disconnect();
  }, [channels.length]);

  useEffect(() => {
    const el = scrollerRef.current;
    if (!el || selectedIndex < 0) return;
    const top = selectedIndex * ROW;
    const bottom = top + ROW;
    if (top < el.scrollTop) el.scrollTop = top;
    else if (bottom > el.scrollTop + el.clientHeight) el.scrollTop = bottom - el.clientHeight;
  }, [selectedIndex]);

  const start = Math.max(0, Math.floor(scrollTop / ROW) - 4);
  const end = Math.min(channels.length, start + Math.ceil(viewport / ROW) + 8);
  const width = String(Math.max(2, String(channels.length || 1).length));

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="safe-t flex flex-wrap items-center gap-3 border-b border-line px-3 py-3 sm:px-4">
        <div className="flex items-center gap-3">
          <span className="grid size-11 place-items-center rounded-2xl glass-soft text-amber">
            <Tv className="size-5" />
          </span>
          <div className="leading-tight">
            <div className="text-lg font-semibold">ركن</div>
            <div className="max-w-40 truncate text-xs text-muted sm:max-w-64">{sourceName}</div>
          </div>
        </div>
        <label className="relative order-last w-full tv:order-none tv:w-80">
          <span className="sr-only">بحث</span>
          <Search className="pointer-events-none absolute start-4 top-1/2 size-4 -translate-y-1/2 text-muted" />
          <input
            suppressHydrationWarning
            className="field field-search"
            placeholder="ابحث عن قناة أو رقم"
            value={query}
            onChange={(event) => onQuery(event.target.value)}
          />
        </label>
        <div className="ms-auto flex items-center gap-2">
          <span className="hidden text-sm text-muted sm:inline">{countLabel}</span>
          <button className="icon-btn" type="button" aria-label="تحديث القائمة" onClick={onRefresh} disabled={loading}>
            <RefreshCw className={cn("size-5", loading && "animate-spin motion-reduce:animate-none")} />
          </button>
          <button className="btn btn-amber" type="button" onClick={onOpenSources}>
            المصادر
          </button>
          <div className="hidden sm:block">
            <Clock />
          </div>
        </div>
      </header>

      {(error || warning || demo) && (
        <div className="border-b border-line px-4 py-2 text-sm">
          {error && <p className="text-live">{error}</p>}
          {!error && warning && <p className="text-amber">{warning}</p>}
          {demo && !error && (
            <p className="text-muted">عيّنات فيديو مجانية لتجربة الجهاز، وليست قنوات اشتراك.</p>
          )}
        </div>
      )}

      <div className="grid min-h-0 flex-1 grid-cols-1 tv:grid-cols-12">
        <nav className={cn("flex gap-2 overflow-x-auto border-b border-line p-3 tv:col-span-3 tv:flex-col tv:overflow-x-hidden tv:overflow-y-auto tv:border-e tv:border-b-0 scroll", !hasChannels && "hidden")}>
          {groups.map((group) => {
            const on = group.id === groupId;
            return (
              <button
                key={group.id}
                type="button"
                onClick={() => onGroup(group.id)}
                className={cn(
                  "flex shrink-0 items-center justify-between gap-3 rounded-full px-4 py-2 text-start text-sm tv:w-full tv:rounded-2xl tv:py-3",
                  on ? "bg-amber font-semibold text-amber-ink" : "glass-soft text-fg",
                )}
              >
                <span className="truncate">{group.label}</span>
                <span className="tabular-nums">{group.count}</span>
              </button>
            );
          })}
        </nav>

        <section className={cn("flex min-h-0 flex-col", hasChannels ? "tv:col-span-6" : "tv:col-span-12")}>
          {channels.length === 0 ? (
            <div className="flex flex-1 flex-col items-center justify-center gap-4 px-6 text-center">
              <span className="grid size-16 place-items-center rounded-3xl glass-soft text-amber">
                <Tv className="size-7" />
              </span>
              <h2 className="text-2xl font-semibold text-balance">
                {loading ? "يجري جلب القائمة" : "لا توجد قنوات بعد"}
              </h2>
              <p className="max-w-sm text-pretty text-muted">
                {loading
                  ? "نحمّل القنوات من المصدر المحفوظ على هذا الجهاز."
                  : "الصق رابط M3U، أو أدخل سيرفر Xtream، أو ارفع ملف القائمة كما في أي ريسيفر."}
              </p>
              {!loading && (
                <button className="btn btn-amber" type="button" onClick={onOpenSources}>
                  إضافة مصدر
                </button>
              )}
            </div>
          ) : (
            <div
              ref={scrollerRef}
              className="scroll min-h-0 flex-1 overflow-y-auto"
              onScroll={(event) => setScrollTop(event.currentTarget.scrollTop)}
              role="listbox"
              aria-label="القنوات"
            >
              <div className="relative" style={{ height: channels.length * ROW }}>
                {channels.slice(start, end).map((channel, index) => {
                  const absolute = start + index;
                  const active = channel.id === selectedId;
                  return (
                    <div
                      key={channel.id}
                      role="option"
                      aria-selected={active}
                      className={cn(
                        "absolute inset-x-0 flex items-center gap-3 border-b border-line px-3",
                        active && "row-on",
                      )}
                      style={{ top: absolute * ROW, height: ROW }}
                    >
                      <button
                        type="button"
                        className="flex min-w-0 flex-1 items-center gap-3 text-start"
                        onClick={() => {
                          onSelect(channel.id);
                          onPlay(channel);
                        }}
                        onFocus={() => onSelect(channel.id)}
                      >
                        <span className="w-12 shrink-0 text-center font-semibold tabular-nums text-amber" dir="ltr">
                          {String(channel.num).padStart(Number(width), "0")}
                        </span>
                        <ChannelLogo name={channel.name} logo={channel.logo} />
                        <span className="min-w-0 flex-1">
                          <span className="block truncate font-medium">{channel.name}</span>
                          <span className="block truncate text-sm text-muted tv:hidden">{channel.group}</span>
                        </span>
                      </button>
                      <span className="hidden max-w-32 truncate text-sm text-muted md:block">{channel.group}</span>
                      <button
                        type="button"
                        className="icon-btn"
                        data-on={favorites.has(channel.id) ? "true" : "false"}
                        aria-label={favorites.has(channel.id) ? "إزالة من المفضلة" : "إضافة للمفضلة"}
                        onClick={() => onToggleFav(channel.id)}
                      >
                        <Star className="size-4" fill={favorites.has(channel.id) ? "currentColor" : "none"} />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <div className="safe-b flex items-center gap-3 border-t border-line p-3 tv:hidden">
            <div className="min-w-0 flex-1">
              <div className="truncate font-medium">{selected?.name ?? "اختر قناة"}</div>
              <div className="truncate text-sm text-muted">{selected?.group ?? "من الريموت أو اللمس"}</div>
            </div>
            <button className="btn btn-amber" type="button" disabled={!selected} onClick={() => selected && onPlay(selected)}>
              تشغيل
            </button>
          </div>
        </section>

        <aside
          className={cn(
            "hidden min-h-0 flex-col justify-between border-line p-5 tv:col-span-3 tv:border-s",
            hasChannels && "tv:flex",
          )}
        >
          {selected ? (
            <div className="grid gap-4">
              <div className="text-5xl font-semibold tabular-nums text-amber" dir="ltr">
                {String(selected.num).padStart(Number(width), "0")}
              </div>
              <ChannelLogo name={selected.name} logo={selected.logo} />
              <div>
                <h2 className="text-2xl font-semibold text-balance">{selected.name}</h2>
                <p className="mt-1 text-muted">{selected.group}</p>
              </div>
              <p className="text-sm text-pretty text-muted">دليل البرامج غير موصول. الرقم ثابت كما في ملف القائمة.</p>
              <div className="flex gap-2">
                <button className="btn btn-amber flex-1" type="button" onClick={() => onPlay(selected)}>
                  تشغيل
                </button>
                <button
                  className="icon-btn"
                  type="button"
                  data-on={favorites.has(selected.id) ? "true" : "false"}
                  aria-label="المفضلة"
                  onClick={() => onToggleFav(selected.id)}
                >
                  <Star className="size-4" fill={favorites.has(selected.id) ? "currentColor" : "none"} />
                </button>
              </div>
            </div>
          ) : (
            <p className="text-muted">اختر قناة من القائمة.</p>
          )}
          <p className="text-sm text-pretty text-muted">
            الريموت: الأعلى والأسفل للتنقل، موافق للتشغيل، الجانبان للصوت أثناء البث، الرجوع للقائمة.
          </p>
        </aside>
      </div>
    </div>
  );
}
