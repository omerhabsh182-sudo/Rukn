import { useEffect, useMemo, useRef, useState } from "react";
import { GuideView } from "@/components/receiver/guide-view";
import { SourceDrawer } from "@/components/receiver/source-drawer";
import { WatchView } from "@/components/receiver/watch-view";
import { fetchPlaylistText, uid } from "@/lib/iptv/client";
import { DEMO_CHANNELS, DEMO_SOURCE_ID } from "@/lib/iptv/demo";
import { buildXtreamUrl, parseM3u } from "@/lib/iptv/parse-m3u";
import { deleteLibrary, loadLibrary, loadPrefs, saveLibrary, savePrefs } from "@/lib/iptv/storage";
import type { Channel, Source } from "@/lib/iptv/types";

const ALL = "__all";
const FAV = "__fav";

function isBackKey(event: KeyboardEvent) {
  return event.key === "Escape" || event.key === "BrowserBack" || event.key === "GoBack" || event.keyCode === 4;
}

export function ReceiverApp() {
  const [hydrated, setHydrated] = useState(false);
  const [sources, setSources] = useState<Source[]>([]);
  const [activeSourceId, setActiveSourceId] = useState<string | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [lastChannelId, setLastChannelId] = useState<string | null>(null);
  const [volume, setVolume] = useState(1);
  const [muted, setMuted] = useState(false);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [warning, setWarning] = useState<string | null>(null);
  const [drawerError, setDrawerError] = useState<string | null>(null);
  const [groupId, setGroupId] = useState(ALL);
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [watching, setWatching] = useState(false);
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [drawer, setDrawer] = useState(false);
  const [reloadToken, setReloadToken] = useState(0);
  const [osd, setOsd] = useState(true);
  const [digits, setDigits] = useState("");
  const digitTimer = useRef<number | null>(null);
  const osdTimer = useRef<number | null>(null);

  useEffect(() => {
    const prefs = loadPrefs();
    setSources(prefs.sources);
    setActiveSourceId(prefs.activeSourceId);
    setFavorites(prefs.favorites);
    setLastChannelId(prefs.lastChannelId);
    setVolume(prefs.volume);
    setMuted(prefs.muted);
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    savePrefs({ sources, activeSourceId, favorites, lastChannelId, volume, muted });
  }, [hydrated, sources, activeSourceId, favorites, lastChannelId, volume, muted]);

  const active = sources.find((source) => source.id === activeSourceId) ?? null;
  const activeKey = active
    ? `${active.id}|${active.kind}|${active.url ?? ""}|${active.username ?? ""}|${active.output ?? ""}`
    : "";

  useEffect(() => {
    if (!hydrated) return;
    const source = sources.find((item) => item.id === activeSourceId) ?? null;
    if (!source) {
      setChannels([]);
      setError(null);
      setLoading(false);
      return;
    }
    let cancel = false;
    void (async () => {
      setLoading(true);
      setError(null);
      setWarning(null);
      const cached = await loadLibrary(source.id);
      if (cancel) return;
      if (cached?.length) setChannels(cached);
      if (source.kind === "file") {
        setLoading(false);
        if (!cached?.length) setError("الملف غير محفوظ على هذا الجهاز. أعد رفعه.");
        return;
      }
      try {
        const playlistUrl = source.kind === "xtream" ? buildXtreamUrl(source) : source.url || "";
        const text = await fetchPlaylistText(playlistUrl);
        const parsed = parseM3u(text, playlistUrl);
        if (!parsed.length) throw new Error("القائمة لا تحتوي قنوات.");
        if (cancel) return;
        setChannels(parsed);
        await saveLibrary(source.id, parsed);
      } catch (loadError) {
        if (cancel) return;
        const message = loadError instanceof Error ? loadError.message : "تعذّر تحميل القائمة.";
        if (cached?.length) setWarning("تعذّر التحديث. تُعرض آخر نسخة محفوظة على الجهاز.");
        else setError(message);
      } finally {
        if (!cancel) setLoading(false);
      }
    })();
    return () => {
      cancel = true;
    };
  }, [hydrated, activeKey, reloadToken, sources, activeSourceId]);

  const favSet = useMemo(() => new Set(favorites), [favorites]);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return channels.filter((channel) => {
      if (groupId === FAV && !favSet.has(channel.id)) return false;
      if (groupId !== ALL && groupId !== FAV && channel.group !== groupId) return false;
      if (!needle) return true;
      return channel.name.toLowerCase().includes(needle) || String(channel.num).includes(needle);
    });
  }, [channels, groupId, query, favSet]);

  useEffect(() => {
    if (!channels.length) {
      setSelectedId(null);
      return;
    }
    setSelectedId((current) => {
      if (current && channels.some((channel) => channel.id === current)) return current;
      if (lastChannelId && channels.some((channel) => channel.id === lastChannelId)) return lastChannelId;
      return channels[0]?.id ?? null;
    });
  }, [channels, lastChannelId]);

  const groups = useMemo(() => {
    const counts = new Map<string, number>();
    for (const channel of channels) counts.set(channel.group, (counts.get(channel.group) ?? 0) + 1);
    return [
      { id: ALL, label: "كل القنوات", count: channels.length },
      { id: FAV, label: "المفضلة", count: channels.filter((channel) => favSet.has(channel.id)).length },
      ...[...counts.entries()].map(([label, count]) => ({ id: label, label, count })),
    ];
  }, [channels, favSet]);

  const showOsd = () => {
    setOsd(true);
    if (osdTimer.current) window.clearTimeout(osdTimer.current);
    osdTimer.current = window.setTimeout(() => setOsd(false), 4500);
  };

  const playChannel = (channel: Channel) => {
    setSelectedId(channel.id);
    setPlayingId(channel.id);
    setLastChannelId(channel.id);
    setWatching(true);
    showOsd();
  };

  const step = (delta: number) => {
    const list = filtered.length ? filtered : channels;
    if (!list.length) return;
    const currentId = watching ? playingId : selectedId;
    const index = list.findIndex((channel) => channel.id === currentId);
    const start = index < 0 ? (delta > 0 ? -1 : 0) : index;
    const next = list[(start + delta + list.length) % list.length];
    if (!next) return;
    setSelectedId(next.id);
    if (watching) {
      setPlayingId(next.id);
      setLastChannelId(next.id);
      showOsd();
    }
  };

  const jumpTo = (num: number) => {
    const channel = channels.find((item) => item.num === num);
    if (!channel) return;
    setGroupId(ALL);
    setQuery("");
    setSelectedId(channel.id);
    if (watching) {
      setPlayingId(channel.id);
      setLastChannelId(channel.id);
      showOsd();
    }
  };

  const pushDigit = (digit: string) => {
    const next = `${digits}${digit}`.slice(-4);
    setDigits(next);
    if (digitTimer.current) window.clearTimeout(digitTimer.current);
    digitTimer.current = window.setTimeout(() => {
      jumpTo(Number(next));
      setDigits("");
    }, 1100);
  };

  const confirmDigits = () => {
    if (!digits) return false;
    if (digitTimer.current) window.clearTimeout(digitTimer.current);
    jumpTo(Number(digits));
    setDigits("");
    return true;
  };

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing = target?.tagName === "INPUT" || target?.tagName === "TEXTAREA";
      if (typing) {
        if (event.key === "Escape") target.blur();
        return;
      }
      if (drawer) {
        if (isBackKey(event)) {
          event.preventDefault();
          setDrawer(false);
        }
        return;
      }
      if (/^[0-9]$/.test(event.key)) {
        event.preventDefault();
        pushDigit(event.key);
        return;
      }
      if (event.key === "Enter" || event.key === "NumpadEnter" || event.key === "Accept" || event.key === "Select") {
        event.preventDefault();
        if (confirmDigits()) return;
        if (!watching) {
          const channel = filtered.find((item) => item.id === selectedId) ?? channels.find((item) => item.id === selectedId);
          if (channel) playChannel(channel);
        } else showOsd();
        return;
      }
      if (event.key === "ArrowDown" || event.key === "ChannelDown" || event.key === "PageDown") {
        event.preventDefault();
        step(1);
        return;
      }
      if (event.key === "ArrowUp" || event.key === "ChannelUp" || event.key === "PageUp") {
        event.preventDefault();
        step(-1);
        return;
      }
      if (watching && (event.key === "ArrowLeft" || event.key === "AudioVolumeDown")) {
        event.preventDefault();
        setMuted(false);
        setVolume((value) => Math.max(0, Math.round((value - 0.05) * 20) / 20));
        showOsd();
        return;
      }
      if (watching && (event.key === "ArrowRight" || event.key === "AudioVolumeUp")) {
        event.preventDefault();
        setMuted(false);
        setVolume((value) => Math.min(1, Math.round((value + 0.05) * 20) / 20));
        showOsd();
        return;
      }
      if (!watching && (event.key === "ArrowLeft" || event.key === "ArrowRight")) {
        event.preventDefault();
        const index = Math.max(0, groups.findIndex((group) => group.id === groupId));
        const delta = event.key === "ArrowLeft" ? 1 : -1;
        const next = groups[(index + delta + groups.length) % groups.length];
        if (next) setGroupId(next.id);
        return;
      }
      if (event.key === "MediaPlayPause" || event.key === " ") {
        event.preventDefault();
        if (watching) showOsd();
        return;
      }
      if ((event.key === "f" || event.key === "F" || event.key === "*") && (playingId || selectedId)) {
        const id = (watching ? playingId : selectedId) as string;
        setFavorites((current) => (current.includes(id) ? current.filter((item) => item !== id) : [...current, id]));
        return;
      }
      if (isBackKey(event) || event.key === "Backspace") {
        if (watching) {
          event.preventDefault();
          setWatching(false);
          setDigits("");
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const toggleFav = (id: string) => {
    setFavorites((current) => (current.includes(id) ? current.filter((item) => item !== id) : [...current, id]));
  };

  const activate = (id: string) => {
    setActiveSourceId(id);
    setGroupId(ALL);
    setQuery("");
    setDrawer(false);
    setWatching(false);
  };

  const remember = async (source: Source, parsed?: Channel[]) => {
    if (parsed) await saveLibrary(source.id, parsed);
    setSources((current) => [source, ...current.filter((item) => item.id !== source.id)]);
    setDrawerError(null);
    activate(source.id);
    if (parsed) setChannels(parsed);
  };

  const playing = channels.find((channel) => channel.id === playingId) ?? null;

  return (
    <main className="room relative h-dvh overflow-hidden text-fg">
      <div className="relative flex h-full p-0 sm:p-3 tv:p-5">
        <div className="glass flex h-full min-h-0 w-full flex-col overflow-hidden sm:rounded-3xl">
          <GuideView
            sourceName={active?.name ?? "لا يوجد مصدر"}
            countLabel={channels.length ? `${channels.length.toLocaleString("en-US")} قناة` : "بانتظار قائمة"}
            loading={loading}
            error={active ? error : null}
            warning={warning}
            demo={active?.id === DEMO_SOURCE_ID}
            hasChannels={channels.length > 0}
            groups={groups}
            groupId={groupId}
            onGroup={setGroupId}
            query={query}
            onQuery={setQuery}
            channels={filtered}
            selectedId={selectedId}
            onSelect={setSelectedId}
            onPlay={playChannel}
            favorites={favSet}
            onToggleFav={toggleFav}
            onOpenSources={() => {
              setDrawerError(null);
              setDrawer(true);
            }}
            onRefresh={() => setReloadToken((value) => value + 1)}
          />
        </div>
      </div>

      {watching && playing && (
        <WatchView
          channel={playing}
          favorite={favSet.has(playing.id)}
          volume={volume}
          muted={muted}
          osd={osd}
          digits={digits}
          onShowOsd={showOsd}
          onClose={() => setWatching(false)}
          onPrev={() => step(-1)}
          onNext={() => step(1)}
          onToggleFav={() => toggleFav(playing.id)}
          onVolume={setVolume}
          onMuted={setMuted}
        />
      )}

      <SourceDrawer
        open={drawer}
        sources={sources}
        activeId={activeSourceId}
        busy={loading && drawer}
        error={drawerError}
        onClose={() => setDrawer(false)}
        onDemo={() => {
          const source: Source = {
            id: DEMO_SOURCE_ID,
            name: "عيّنات مجانية",
            kind: "file",
            createdAt: Date.now(),
          };
          void remember(source, DEMO_CHANNELS);
        }}
        onActivate={activate}
        onDelete={(id) => {
          setSources((current) => current.filter((source) => source.id !== id));
          if (activeSourceId === id) {
            setActiveSourceId(null);
            setChannels([]);
            setWatching(false);
          }
          void deleteLibrary(id);
        }}
        onFile={(file, name) => {
          void file.text().then(async (text) => {
            const parsed = parseM3u(text);
            if (!parsed.length) {
              setDrawerError("الملف ليس قائمة M3U أو لا يحتوي قنوات.");
              return;
            }
            const source: Source = {
              id: uid("file"),
              name: name.trim() || file.name.replace(/\.m3u8?$/i, "") || "ملف",
              kind: "file",
              createdAt: Date.now(),
            };
            await remember(source, parsed);
          });
        }}
        onSave={(draft) => {
          try {
            if (draft.kind === "xtream") {
              const url = buildXtreamUrl(draft);
              const source: Source = {
                id: uid("xtream"),
                name: draft.name.trim() || draft.username.trim() || "Xtream",
                kind: "xtream",
                url: draft.url.trim(),
                username: draft.username.trim(),
                password: draft.password,
                output: draft.output,
                createdAt: Date.now(),
              };
              void url;
              void remember(source);
              return;
            }
            const raw = draft.url.trim();
            if (!raw) {
              setDrawerError("الصق رابط القائمة.");
              return;
            }
            const normalized = /^https?:\/\//i.test(raw) ? raw : `http://${raw}`;
            new URL(normalized);
            const source: Source = {
              id: uid("url"),
              name: draft.name.trim() || "قائمة M3U",
              kind: "url",
              url: normalized,
              createdAt: Date.now(),
            };
            void remember(source);
          } catch (saveError) {
            setDrawerError(saveError instanceof Error ? saveError.message : "تعذّر حفظ المصدر.");
          }
        }}
      />
    </main>
  );
}
