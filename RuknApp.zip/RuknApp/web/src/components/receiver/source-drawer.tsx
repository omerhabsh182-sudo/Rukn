import { useEffect, useId, useState } from "react";
import { FileUp, Link2, Server, Trash2, X } from "lucide-react";
import { cn } from "@/lib/cn";
import type { Source, SourceKind } from "@/lib/iptv/types";

type Draft = {
  kind: SourceKind;
  name: string;
  url: string;
  username: string;
  password: string;
  output: "m3u8" | "ts";
};

const emptyDraft: Draft = {
  kind: "url",
  name: "",
  url: "",
  username: "",
  password: "",
  output: "m3u8",
};

export function SourceDrawer({
  open,
  sources,
  activeId,
  busy,
  error,
  onClose,
  onSave,
  onFile,
  onActivate,
  onDelete,
  onDemo,
}: {
  open: boolean;
  sources: Source[];
  activeId: string | null;
  busy: boolean;
  error: string | null;
  onClose: () => void;
  onSave: (draft: Draft) => void;
  onFile: (file: File, name: string) => void;
  onActivate: (id: string) => void;
  onDelete: (id: string) => void;
  onDemo: () => void;
}) {
  const [draft, setDraft] = useState<Draft>(emptyDraft);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const titleId = useId();

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center tv:items-center" role="presentation">
      <button className="absolute inset-0 bg-ink/70" aria-label="إغلاق" onClick={onClose} />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        className="glass rise safe-b relative z-10 max-h-[92dvh] w-full overflow-y-auto rounded-t-3xl p-5 tv:max-w-xl tv:rounded-3xl"
      >
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h2 id={titleId} className="text-xl font-semibold text-balance">
              المصادر
            </h2>
            <p className="mt-1 text-sm text-pretty text-muted">
              رابط M3U، أو بيانات Xtream، أو ملف من الجهاز. ركن لا يأتي بقنوات جاهزة.
            </p>
          </div>
          <button className="icon-btn" onClick={onClose} aria-label="إغلاق">
            <X className="size-5" />
          </button>
        </div>

        <div className="mb-4 grid grid-cols-3 gap-2">
          {(
            [
              ["url", "رابط", Link2],
              ["xtream", "Xtream", Server],
              ["file", "ملف", FileUp],
            ] as const
          ).map(([kind, label, Icon]) => (
            <button
              key={kind}
              className={cn("btn", draft.kind === kind ? "btn-amber" : "btn-glass")}
              onClick={() => setDraft((current) => ({ ...current, kind }))}
              type="button"
            >
              <Icon className="size-4" />
              {label}
            </button>
          ))}
        </div>

        <form
          className="grid gap-3"
          onSubmit={(event) => {
            event.preventDefault();
            if (draft.kind === "file") return;
            onSave(draft);
          }}
        >
          <label className="grid gap-1 text-sm text-muted">
            الاسم على الجهاز
            <input
              className="field"
              value={draft.name}
              placeholder="بيت، المكتب…"
              onChange={(event) => setDraft({ ...draft, name: event.target.value })}
            />
          </label>

          {draft.kind !== "file" && (
            <label className="grid gap-1 text-sm text-muted">
              {draft.kind === "url" ? "رابط القائمة" : "عنوان السيرفر"}
              <input
                className="field"
                dir="ltr"
                inputMode="url"
                autoCapitalize="off"
                autoCorrect="off"
                spellCheck={false}
                placeholder={draft.kind === "url" ? "https://example.com/list.m3u" : "http://host:8080"}
                value={draft.url}
                onChange={(event) => setDraft({ ...draft, url: event.target.value })}
              />
            </label>
          )}

          {draft.kind === "xtream" && (
            <>
              <label className="grid gap-1 text-sm text-muted">
                اسم المستخدم
                <input
                  className="field"
                  dir="ltr"
                  autoCapitalize="off"
                  value={draft.username}
                  onChange={(event) => setDraft({ ...draft, username: event.target.value })}
                />
              </label>
              <label className="grid gap-1 text-sm text-muted">
                كلمة المرور
                <input
                  className="field"
                  dir="ltr"
                  type="password"
                  autoComplete="off"
                  value={draft.password}
                  onChange={(event) => setDraft({ ...draft, password: event.target.value })}
                />
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  className={cn("btn", draft.output === "m3u8" ? "btn-amber" : "btn-glass")}
                  onClick={() => setDraft({ ...draft, output: "m3u8" })}
                >
                  HLS
                </button>
                <button
                  type="button"
                  className={cn("btn", draft.output === "ts" ? "btn-amber" : "btn-glass")}
                  onClick={() => setDraft({ ...draft, output: "ts" })}
                >
                  TS
                </button>
              </div>
              <p className="text-sm text-muted">HLS أنسب لمتصفح الشاشة. TS لبعض السيرفرات القديمة.</p>
            </>
          )}

          {draft.kind === "file" ? (
            <label className="btn btn-amber">
              <FileUp className="size-4" />
              اختيار ملف m3u
              <input
                className="sr-only"
                type="file"
                accept=".m3u,.m3u8,audio/x-mpegurl,application/vnd.apple.mpegurl,application/x-mpegURL"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  if (file) onFile(file, draft.name);
                  event.target.value = "";
                }}
              />
            </label>
          ) : (
            <button className="btn btn-amber" type="submit" disabled={busy}>
              {busy ? "جارٍ الجلب…" : "حفظ وتشغيل"}
            </button>
          )}
          {error && <p className="text-sm text-live">{error}</p>}
        </form>

        <div className="mt-5 border-t border-line pt-4">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="font-medium">المحفوظ على الجهاز</h3>
            <button className="btn btn-glass" type="button" onClick={onDemo}>
              عيّنة مجانية
            </button>
          </div>
          {sources.length === 0 ? (
            <p className="text-sm text-muted">لا مصادر بعد.</p>
          ) : (
            <ul className="grid gap-2">
              {sources.map((source) => (
                <li key={source.id} className="glass-soft flex items-center gap-2 rounded-2xl px-3 py-2">
                  <button className="min-w-0 flex-1 text-start" type="button" onClick={() => onActivate(source.id)}>
                    <span className="block truncate font-medium">
                      {source.name}
                      {source.id === activeId ? " · الحالي" : ""}
                    </span>
                    <span className="block truncate text-sm text-muted">
                      {source.kind === "xtream" ? "Xtream" : source.kind === "file" ? "ملف" : "رابط"}
                    </span>
                  </button>
                  <button
                    className="icon-btn"
                    type="button"
                    aria-label={confirmId === source.id ? "تأكيد الحذف" : "حذف المصدر"}
                    onClick={() => {
                      if (confirmId === source.id) {
                        onDelete(source.id);
                        setConfirmId(null);
                      } else setConfirmId(source.id);
                    }}
                  >
                    <Trash2 className="size-4" />
                  </button>
                </li>
              ))}
            </ul>
          )}
          <p className="mt-3 text-sm text-pretty text-muted">
            بيانات الدخول تبقى في متصفح هذه الشاشة فقط. العيّنة أفلام قصيرة مجانية لتجربة الصورة، وليست اشتراكاً.
          </p>
        </div>
      </div>
    </div>
  );
}
