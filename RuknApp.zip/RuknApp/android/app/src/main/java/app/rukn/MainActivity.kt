package app.rukn

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.*
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private lateinit var w: WebView
    private var custom: View? = null
    private var cb: ValueCallback<Array<Uri>>? = null
    private var lastBack = 0L
    private val host = "appassets.androidplatform.net"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        w = WebView(this)
        w.setBackgroundColor(0xFF07090D.toInt())
        setContentView(w)
        w.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val u = r.url
                if (u.host == host) return asset(u.path ?: "/")
                if (r.method != "GET" || (u.scheme != "http" && u.scheme != "https")) return null
                return try { proxy(r) } catch (e: Exception) {
                    WebResourceResponse("text/plain", "utf-8", 502, "Bad Gateway", cors(),
                        ByteArrayInputStream(ByteArray(0)))
                }
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(v: View, c: CustomViewCallback) {
                custom = v; addContentView(v, ViewGroup.LayoutParams(-1, -1)); w.visibility = View.GONE
            }
            override fun onHideCustomView() {
                custom?.let { (it.parent as ViewGroup).removeView(it) }; custom = null; w.visibility = View.VISIBLE
            }
            override fun onShowFileChooser(v: WebView, c: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                cb?.onReceiveValue(null); cb = c
                try { startActivityForResult(p.createIntent(), 1) } catch (e: Exception) { cb = null; return false }
                return true
            }
        }
        w.loadUrl("https://$host/index.html")
    }

    private fun cors() = mutableMapOf("Access-Control-Allow-Origin" to "*", "Access-Control-Expose-Headers" to "*")

    private fun asset(path: String): WebResourceResponse {
        val p = path.trimStart('/').ifEmpty { "index.html" }
        return try {
            val mime = when (p.substringAfterLast('.', "")) {
                "html" -> "text/html"; "js", "mjs" -> "text/javascript"; "css" -> "text/css"
                "svg" -> "image/svg+xml"; "png" -> "image/png"; "jpg" -> "image/jpeg"
                "json" -> "application/json"; "woff2" -> "font/woff2"; else -> "application/octet-stream"
            }
            WebResourceResponse(mime, "utf-8", assets.open(p))
        } catch (e: Exception) {
            WebResourceResponse("text/plain", "utf-8", 404, "Not Found", cors(), ByteArrayInputStream(ByteArray(0)))
        }
    }

    // يجلب أي رابط خارجي نيابةً عن الصفحة ويضيف ترويسات CORS، فلا حاجة لخادم وسيط.
    private fun proxy(r: WebResourceRequest): WebResourceResponse {
        var url = r.url.toString()
        var c: HttpURLConnection
        var hops = 0
        while (true) {
            c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15000; c.readTimeout = 30000; c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "VLC/3.0.21 LibVLC/3.0.21")
            r.requestHeaders["Range"]?.let { c.setRequestProperty("Range", it) }
            val code = c.responseCode
            if (code in 300..399 && hops++ < 5) {
                val loc = c.getHeaderField("Location") ?: break
                url = URL(URL(url), loc).toString(); c.disconnect(); continue
            }
            break
        }
        val code = c.responseCode
        val ct = c.contentType ?: "application/octet-stream"
        val mime = ct.substringBefore(";").trim()
        val enc = Regex("charset=([^;]+)", RegexOption.IGNORE_CASE).find(ct)?.groupValues?.get(1)?.trim()
        val h = cors()
        c.getHeaderField("Content-Range")?.let { h["Content-Range"] = it }
        c.getHeaderField("Accept-Ranges")?.let { h["Accept-Ranges"] = it }
        if (c.contentLengthLong >= 0) h["Content-Length"] = c.contentLengthLong.toString()
        val stream = if (code >= 400) c.errorStream ?: ByteArrayInputStream(ByteArray(0)) else c.inputStream
        val safe = if (code in 100..299 || code in 400..599) code else 502
        return WebResourceResponse(mime, enc, safe, c.responseMessage?.ifEmpty { null } ?: "OK", h, stream)
    }

    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        if (r == 1) { cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, d)); cb = null }
    }

    override fun onBackPressed() {
        val now = System.currentTimeMillis()
        if (now - lastBack < 700) { super.onBackPressed(); return }
        lastBack = now
        w.evaluateJavascript("document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',keyCode:27,bubbles:true}))", null)
    }

    override fun onPause() { super.onPause(); w.onPause() }
    override fun onResume() { super.onResume(); w.onResume() }
}
