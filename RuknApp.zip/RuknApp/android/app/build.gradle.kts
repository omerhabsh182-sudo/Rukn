plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "app.rukn"
    compileSdk = 34
    defaultConfig { applicationId = "app.rukn"; minSdk = 23; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
